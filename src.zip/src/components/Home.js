import React from 'react';
import './../App.css';
import myImage from './admin (2).png';

const Home = () => {
  return (
    <div className="introduction">
        <div >
            <h1>Sneha Choudhari</h1>
            <p>I’m pursuing post graduate from Jain University for Full Stack Development Specialization. I’ve been working on various projects
                to be reconginzed as a Full Stack Web Developer through TrakLabs Bootcamp to boost my career. I am excited 
                to start my new journey in the world on creativity. </p>
            <p>Refer my profile on:
                <a href="https://www.linkedin.com/in/sneha-chaudhari-6294a3180" >Linked-in</a>
                <a href="https://github.com/Sneha14-sc?tab=repositories">GitHub</a>
            </p>
        </div>
        <img src={myImage} alt="loading" className="img"/>
    </div>
)
}

export default Home;