import React from 'react'
import './../App.css';

const Project = () => {
  return (
    <div className="lists">
        <h2>Projects</h2>
        <ul>
            <li>StickyNotes APP using React</li>
            <li>StickyNotes App using Javascript only</li>
            <li>Global time display App</li>
            <li>Few AWS projects</li>
            <li>Final year Project(Garbage Collector Board) using Java language</li>
        </ul>
    </div>
  )
}

export default Project